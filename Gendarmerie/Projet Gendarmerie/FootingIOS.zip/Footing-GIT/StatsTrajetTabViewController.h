//
//  StatsTrajetTabViewController.h
//  Footing
//
//  Created by admin on 29/05/13.
//  Copyright (c) 2013 Quentin Bontemps. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Trajet.h"

@interface StatsTrajetTabViewController : UITabBarController

@property (strong, nonatomic) Trajet *trajet;

@end
