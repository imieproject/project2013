//
//  Constant.h
//  Footing
//
//  Created by admin on 06/05/13.
//  Copyright (c) 2013 Quentin Bontemps. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Constant : NSObject

enum constant{
    
    PARCOURS_STORE = 1,
    CIRCUITS_STORE = 2,
    ANCIEN_PARCOURS = 3
};

@end
