//
//  StatsViewController.h
//  Footing
//
//  Created by admin on 05/06/13.
//  Copyright (c) 2013 Quentin Bontemps. All rights reserved.
//

#import "ViewController.h"
#import "Tools.h"

@interface StatsViewController : ViewController

@property (strong, nonatomic)IBOutlet UIButton *btnTrajet;
@property (strong, nonatomic)IBOutlet UIButton *btnGlobales;

@end
