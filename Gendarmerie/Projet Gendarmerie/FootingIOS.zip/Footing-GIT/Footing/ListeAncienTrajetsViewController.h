//
//  ListeAncienTrajetsViewController.h
//  Footing
//
//  Created by admin on 27/05/13.
//  Copyright (c) 2013 Quentin Bontemps. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"

@interface ListeAncienTrajetsViewController : UITabBarController<UITabBarDelegate>

@property (nonatomic, strong) NSNumber *isStats;

@end
