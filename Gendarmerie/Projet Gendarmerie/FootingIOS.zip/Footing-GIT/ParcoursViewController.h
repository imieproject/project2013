//
//  ParcoursViewController.h
//  Footing
//
//  Created by admin on 13/05/13.
//  Copyright (c) 2013 Quentin Bontemps. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"
#import "Tools.h"

@interface ParcoursViewController : UIViewController

@property (nonatomic, strong)IBOutlet UIButton *btnNxParcours;
@property (nonatomic, strong)IBOutlet UIButton *btnListeParcours;

@end
